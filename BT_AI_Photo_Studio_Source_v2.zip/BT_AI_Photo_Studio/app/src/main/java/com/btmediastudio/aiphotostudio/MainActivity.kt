package com.btmediastudio.aiphotostudio

import android.content.ContentValues
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix as ComposeColorMatrix
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

private val Blue = Color(0xFF1769E0)
private val Navy = Color(0xFF102A4C)
private val PaleBlue = Color(0xFFEAF3FF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { BtPhotoStudioApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BtPhotoStudioApp() {
    val context = LocalContext.current
    var sourceUri by remember { mutableStateOf<Uri?>(null) }
    var bitmap by remember { mutableStateOf<Bitmap?>(null) }
    var mode by remember { mutableStateOf("Home") }
    var brightness by remember { mutableFloatStateOf(1f) }
    var contrast by remember { mutableFloatStateOf(1f) }
    var saturation by remember { mutableFloatStateOf(1f) }
    var rotation by remember { mutableIntStateOf(0) }
    var gray by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            sourceUri = uri
            busy = true
        }
    }

    LaunchedEffect(sourceUri) {
        val uri = sourceUri ?: return@LaunchedEffect
        bitmap = withContext(Dispatchers.IO) {
            context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
        }
        brightness = 1f; contrast = 1f; saturation = 1f; rotation = 0; gray = false
        mode = "Simple Editor"
        busy = false
    }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Blue, onPrimary = Color.White, secondary = Color(0xFF55A6FF),
            background = Color(0xFFF7FAFF), surface = Color.White, onSurface = Navy
        )
    ) {
        Scaffold(
            containerColor = Color(0xFFF7FAFF),
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("BT AI Photo Studio", fontWeight = FontWeight.Bold, color = Navy)
                            Text("Create. Edit. Shine.", fontSize = 11.sp, color = Blue)
                        }
                    },
                    actions = {
                        if (bitmap != null) IconButton(onClick = {
                            mode = "Home"; bitmap = null; sourceUri = null
                        }) { Icon(Icons.Default.Home, contentDescription = "Home", tint = Blue) }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
                )
            },
            bottomBar = {
                if (bitmap != null) {
                    NavigationBar(containerColor = Color.White) {
                        NavigationBarItem(selected = mode == "Simple Editor", onClick = { mode = "Simple Editor" },
                            icon = { Icon(Icons.Default.Tune, null) }, label = { Text("Simple") })
                        NavigationBarItem(selected = mode == "Professional Editor", onClick = { mode = "Professional Editor" },
                            icon = { Icon(Icons.Default.AutoFixHigh, null) }, label = { Text("Pro") })
                        NavigationBarItem(selected = false, onClick = {
                            saveEditedImage(context, bitmap!!, brightness, contrast, saturation, rotation, gray)
                        }, icon = { Icon(Icons.Default.SaveAlt, null) }, label = { Text("Save") })
                    }
                }
            }
        ) { padding ->
            when {
                busy -> Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = Blue)
                }
                bitmap == null -> HomeScreen(Modifier.padding(padding), onPick = { picker.launch("image/*") })
                else -> EditorScreen(
                    modifier = Modifier.padding(padding), bitmap = bitmap!!, mode = mode,
                    brightness = brightness, onBrightness = { brightness = it },
                    contrast = contrast, onContrast = { contrast = it },
                    saturation = saturation, onSaturation = { saturation = it },
                    rotation = rotation, onRotate = { rotation = (rotation + 90) % 360 },
                    gray = gray, onGray = { gray = !gray },
                    onSave = { saveEditedImage(context, bitmap!!, brightness, contrast, saturation, rotation, gray) }
                )
            }
        }
    }
}

@Composable
private fun HomeScreen(modifier: Modifier = Modifier, onPick: () -> Unit) {
    Column(modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
        Card(
            colors = CardDefaults.cardColors(containerColor = Blue),
            shape = RoundedCornerShape(26.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(Modifier.padding(22.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Your photos, beautifully edited", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Bold)
                Text("Simple tools for quick edits. Pro controls when you need them.", color = Color.White.copy(alpha = .9f))
                Button(onClick = onPick, colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Blue)) {
                    Icon(Icons.Default.AddPhotoAlternate, null)
                    Spacer(Modifier.width(8.dp))
                    Text("Choose a Photo", fontWeight = FontWeight.Bold)
                }
            }
        }
        Text("Editing tools", color = Navy, fontSize = 19.sp, fontWeight = FontWeight.Bold)
        val tools = listOf(
            "Photo Editor" to Icons.Default.Edit,
            "Brightness" to Icons.Default.Brightness6,
            "Filters" to Icons.Default.FilterVintage,
            "Rotate & Crop" to Icons.Default.CropRotate,
            "Image Export" to Icons.Default.FileDownload
        )
        tools.chunked(2).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                row.forEach { item ->
                    Card(
                        modifier = Modifier.weight(1f).height(104.dp).clickable { onPick() },
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        shape = RoundedCornerShape(18.dp),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Column(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.Center) {
                            Icon(item.second, null, tint = Blue, modifier = Modifier.size(27.dp))
                            Spacer(Modifier.height(8.dp))
                            Text(item.first, color = Navy, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
                if (row.size == 1) Spacer(Modifier.weight(1f))
            }
        }
        Spacer(Modifier.weight(1f))
        Text("Offline editing • Your photos stay on your device", color = Color.Gray, fontSize = 12.sp)
    }
}

@Composable
private fun EditorScreen(
    modifier: Modifier,
    bitmap: Bitmap,
    mode: String,
    brightness: Float, onBrightness: (Float) -> Unit,
    contrast: Float, onContrast: (Float) -> Unit,
    saturation: Float, onSaturation: (Float) -> Unit,
    rotation: Int, onRotate: () -> Unit,
    gray: Boolean, onGray: () -> Unit,
    onSave: () -> Unit
) {
    val matrix = remember(brightness, contrast, saturation, gray) {
        makeComposeColorMatrix(brightness, contrast, saturation, gray)
    }
    Column(modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 10.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Column {
                Text(mode, color = Navy, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text("Adjust your image", color = Color.Gray, fontSize = 12.sp)
            }
            TextButton(onClick = onSave) { Icon(Icons.Default.Save, null); Spacer(Modifier.width(5.dp)); Text("Save") }
        }
        Spacer(Modifier.height(10.dp))
        Box(
            Modifier.weight(1f).fillMaxWidth().clip(RoundedCornerShape(20.dp))
                .background(Color(0xFFE7EDF6)).border(1.dp, Color(0xFFD6E2F2), RoundedCornerShape(20.dp)),
            contentAlignment = Alignment.Center
        ) {
            Image(
                bitmap = bitmap.asImageBitmap(),
                contentDescription = "Photo preview",
                modifier = Modifier.fillMaxSize().padding(8.dp).graphicsLayer { rotationZ = rotation.toFloat() },
                contentScale = ContentScale.Fit,
                colorFilter = ColorFilter.colorMatrix(matrix)
            )
        }
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = !gray, onClick = { if (gray) onGray() }, label = { Text("Color") })
            FilterChip(selected = gray, onClick = { if (!gray) onGray() }, label = { Text("B&W") })
            OutlinedButton(onClick = onRotate) { Icon(Icons.Default.RotateRight, null); Text(" Rotate") }
        }
        if (mode == "Simple Editor") {
            AdjustmentSlider("Brightness", brightness, 0f..2f, onBrightness)
        } else {
            AdjustmentSlider("Brightness", brightness, 0f..2f, onBrightness)
            AdjustmentSlider("Contrast", contrast, 0.5f..2f, onContrast)
            AdjustmentSlider("Saturation", saturation, 0f..2f, onSaturation)
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            TextButton(onClick = {
                onBrightness(1f); onContrast(1f); onSaturation(1f)
                if (gray) onGray()
            }) { Text("Reset") }
            Text("Changes are previewed live", color = Color.Gray, fontSize = 11.sp)
        }
    }
}

@Composable
private fun AdjustmentSlider(label: String, value: Float, range: ClosedFloatingPointRange<Float>, onValue: (Float) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(0.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, color = Navy, fontWeight = FontWeight.Medium, fontSize = 13.sp)
            Text("${(value * 100).roundToInt()}%", color = Blue, fontSize = 12.sp)
        }
        Slider(value = value, onValueChange = onValue, valueRange = range, colors = SliderDefaults.colors(thumbColor = Blue, activeTrackColor = Blue))
    }
}

private fun makeComposeColorMatrix(brightness: Float, contrast: Float, saturation: Float, gray: Boolean): ComposeColorMatrix {
    val b = brightness
    val c = contrast
    val s = if (gray) 0f else saturation
    val translate = 128f * (1f - c)
    val cm = android.graphics.ColorMatrix().apply {
        setSaturation(s)
        val adjust = android.graphics.ColorMatrix(floatArrayOf(
            c, 0f, 0f, 0f, translate,
            0f, c, 0f, 0f, translate,
            0f, 0f, c, 0f, translate,
            0f, 0f, 0f, 1f, 0f
        ))
        postConcat(adjust)
        postConcat(android.graphics.ColorMatrix(floatArrayOf(
            b,0f,0f,0f,0f, 0f,b,0f,0f,0f, 0f,0f,b,0f,0f, 0f,0f,0f,1f,0f
        )))
    }
    return ComposeColorMatrix(cm.array)
}

private fun saveEditedImage(
    context: android.content.Context,
    original: Bitmap,
    brightness: Float,
    contrast: Float,
    saturation: Float,
    rotation: Int,
    gray: Boolean
) {
    try {
        val output = Bitmap.createBitmap(original.width, original.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(output)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        val cm = android.graphics.ColorMatrix().apply {
            setSaturation(if (gray) 0f else saturation)
            val translate = 128f * (1f - contrast)
            postConcat(android.graphics.ColorMatrix(floatArrayOf(
                contrast,0f,0f,0f,translate, 0f,contrast,0f,0f,translate,
                0f,0f,contrast,0f,translate, 0f,0f,0f,1f,0f
            )))
            postConcat(android.graphics.ColorMatrix(floatArrayOf(
                brightness,0f,0f,0f,0f, 0f,brightness,0f,0f,0f,
                0f,0f,brightness,0f,0f, 0f,0f,0f,1f,0f
            )))
        }
        paint.colorFilter = ColorMatrixColorFilter(cm)
        canvas.save()
        if (rotation != 0) {
            canvas.rotate(rotation.toFloat(), output.width / 2f, output.height / 2f)
        }
        canvas.drawBitmap(original, 0f, 0f, paint)
        canvas.restore()

        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "BT_Photo_${System.currentTimeMillis()}.jpg")
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/BT AI Photo Studio")
        }
        val uri = context.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
        if (uri != null) {
            context.contentResolver.openOutputStream(uri)?.use { output.compress(Bitmap.CompressFormat.JPEG, 95, it) }
            Toast.makeText(context, "Photo saved to Pictures/BT AI Photo Studio", Toast.LENGTH_LONG).show()
        } else {
            Toast.makeText(context, "Could not save photo", Toast.LENGTH_SHORT).show()
        }
    } catch (e: Exception) {
        Toast.makeText(context, "Save failed: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
    }
}
