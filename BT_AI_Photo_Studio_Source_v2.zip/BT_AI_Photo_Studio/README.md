# BT AI Photo Studio

Starter Android project for BT Media Studio.

## Included in this first source build
- White + blue Material 3 interface
- Android photo picker (no broad storage permission)
- Simple editor: brightness, black & white, rotate
- Professional editor: brightness, contrast, saturation, black & white, rotate
- Live preview and JPEG export to Pictures/BT AI Photo Studio
- Android 8.0+ minimum (API 26)
- Kotlin + Jetpack Compose

## Not yet included
AI background removal, object removal, generative fill, AI enhancement, crop handles,
passport templates, collage layouts, AdMob, subscriptions, and cloud processing.
These require separate implementation and testing. This starter does not claim those
AI features are already working.

## Build
Open this folder in Android Studio (JDK 17), allow Gradle sync, then Build > Build Bundle(s) / APK(s).
Gradle wrapper is not bundled; Android Studio can use its installed Gradle or generate wrapper files.

Package: `com.btmediastudio.aiphotostudio`
Version: `1.0.0` (starter)
